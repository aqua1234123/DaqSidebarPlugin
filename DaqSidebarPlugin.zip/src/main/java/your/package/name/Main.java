package your.package.name;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("DaqSidebarPlugin 有効化されました！");
    }

    @Override
    public void onDisable() {
        getLogger().info("DaqSidebarPlugin 無効化されました！");
    }
}
